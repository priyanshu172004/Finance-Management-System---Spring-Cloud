package com.example.service;

import com.example.model.FinancialGoal;
import com.example.model.User;
import com.example.repository.FinancialGoalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class FinancialGoalService {

    @Autowired
    private FinancialGoalRepository goalRepository;

    @Transactional(readOnly = true)
    public List<FinancialGoal> getUserGoals(User user) {
        return goalRepository.findByUserAndActiveTrueOrderByTargetDateAsc(user);
    }

    @Transactional(readOnly = true)
    public List<FinancialGoal> getActiveGoals(User user) {
        return goalRepository.findByUserAndCompletedFalseAndActiveTrue(user);
    }

    @Transactional(readOnly = true)
    public List<FinancialGoal> getOverdueGoals(User user) {
        return goalRepository.findOverdueGoalsForUser(user, LocalDate.now());
    }

    @Transactional
    public FinancialGoal createGoal(FinancialGoal goal) {
        return goalRepository.save(goal);
    }

    @Transactional
    public FinancialGoal updateGoal(FinancialGoal goal) {
        return goalRepository.save(goal);
    }

    @Transactional
    public FinancialGoal updateGoalProgress(Long goalId, Double amount) {
        Optional<FinancialGoal> optionalGoal = goalRepository.findById(goalId);
        if (optionalGoal.isPresent()) {
            FinancialGoal goal = optionalGoal.get();
            goal.setCurrentAmount(Math.max(0, goal.getCurrentAmount() + amount));

            // Auto-complete if target is reached
            if (goal.getCurrentAmount() >= goal.getTargetAmount()) {
                goal.setCompleted(true);
            }

            return goalRepository.save(goal);
        }
        throw new RuntimeException("Goal not found with id: " + goalId);
    }

    @Transactional
    public void deleteGoal(Long goalId) {
        Optional<FinancialGoal> goal = goalRepository.findById(goalId);
        if (goal.isPresent()) {
            FinancialGoal g = goal.get();
            g.setActive(false);
            goalRepository.save(g);
        }
    }

    @Transactional(readOnly = true)
    public Optional<FinancialGoal> getGoalById(Long id) {
        return goalRepository.findById(id);
    }

    @Transactional(readOnly = true)
    public GoalSummary getGoalSummary(User user) {
        Long completedGoals = goalRepository.countCompletedGoalsForUser(user);
        Double totalTarget = goalRepository.getTotalTargetAmountForUser(user);
        Double totalCurrent = goalRepository.getTotalCurrentAmountForUser(user);
        List<FinancialGoal> activeGoals = getActiveGoals(user);

        if (totalTarget == null)
            totalTarget = 0.0;
        if (totalCurrent == null)
            totalCurrent = 0.0;
        if (completedGoals == null)
            completedGoals = 0L;

        return new GoalSummary(
                completedGoals,
                (long) activeGoals.size(),
                totalTarget,
                totalCurrent,
                totalTarget - totalCurrent);
    }

    @Transactional(readOnly = true)
    public List<FinancialGoal> getGoalsByType(User user, FinancialGoal.GoalType type) {
        return goalRepository.findByUserAndGoalType(user, type);
    }

    @Transactional(readOnly = true)
    public List<FinancialGoal> getGoalsByPriority(User user, FinancialGoal.Priority priority) {
        return goalRepository.findByUserAndPriority(user, priority);
    }

    public static class GoalSummary {
        private final Long completedGoals;
        private final Long activeGoals;
        private final Double totalTarget;
        private final Double totalCurrent;
        private final Double remaining;

        public GoalSummary(Long completedGoals, Long activeGoals, Double totalTarget,
                Double totalCurrent, Double remaining) {
            this.completedGoals = completedGoals;
            this.activeGoals = activeGoals;
            this.totalTarget = totalTarget;
            this.totalCurrent = totalCurrent;
            this.remaining = remaining;
        }

        public Long getCompletedGoals() {
            return completedGoals;
        }

        public Long getActiveGoals() {
            return activeGoals;
        }

        public Double getTotalTarget() {
            return totalTarget;
        }

        public Double getTotalCurrent() {
            return totalCurrent;
        }

        public Double getRemaining() {
            return remaining;
        }

        public Double getProgressPercentage() {
            return totalTarget > 0 ? (totalCurrent / totalTarget) * 100 : 0.0;
        }
    }
}