package com.example.repository;

import com.example.model.FinancialGoal;
import com.example.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface FinancialGoalRepository extends JpaRepository<FinancialGoal, Long> {

    List<FinancialGoal> findByUserAndActiveTrue(User user);

    List<FinancialGoal> findByUserAndActiveTrueOrderByTargetDateAsc(User user);

    List<FinancialGoal> findByUserAndCompletedFalseAndActiveTrue(User user);

    @Query("SELECT g FROM FinancialGoal g WHERE g.user = :user AND g.targetDate < :currentDate AND g.completed = false AND g.active = true")
    List<FinancialGoal> findOverdueGoalsForUser(@Param("user") User user, @Param("currentDate") LocalDate currentDate);

    @Query("SELECT g FROM FinancialGoal g WHERE g.user = :user AND g.goalType = :goalType AND g.active = true")
    List<FinancialGoal> findByUserAndGoalType(@Param("user") User user,
            @Param("goalType") FinancialGoal.GoalType goalType);

    @Query("SELECT g FROM FinancialGoal g WHERE g.user = :user AND g.priority = :priority AND g.active = true")
    List<FinancialGoal> findByUserAndPriority(@Param("user") User user,
            @Param("priority") FinancialGoal.Priority priority);

    @Query("SELECT COUNT(g) FROM FinancialGoal g WHERE g.user = :user AND g.completed = true")
    Long countCompletedGoalsForUser(@Param("user") User user);

    @Query("SELECT SUM(g.targetAmount) FROM FinancialGoal g WHERE g.user = :user AND g.active = true AND g.completed = false")
    Double getTotalTargetAmountForUser(@Param("user") User user);

    @Query("SELECT SUM(g.currentAmount) FROM FinancialGoal g WHERE g.user = :user AND g.active = true AND g.completed = false")
    Double getTotalCurrentAmountForUser(@Param("user") User user);
}