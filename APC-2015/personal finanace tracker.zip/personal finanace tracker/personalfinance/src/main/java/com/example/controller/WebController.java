package com.example.controller;

import com.example.model.Account;
import com.example.model.Transaction;
import com.example.model.User;
import com.example.model.Wallet;
import com.example.service.FinanceService;
import com.example.service.UserService;
import com.example.service.WalletService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class WebController {

    @Autowired
    private FinanceService financeService;

    @Autowired
    private UserService userService;

    @Autowired
    private WalletService walletService;

    @GetMapping("/")
    public String home(Model model, java.security.Principal principal) {
        if (principal == null) {
            // User is not authenticated, show landing page
            return "landing";
        }

        // User is authenticated, redirect to dashboard
        return "redirect:/dashboard";
    }

    @GetMapping("/create-user")
    public String createUserForm() {
        return "create-user";
    }

    @PostMapping("/create-user")
    public String createUser(@RequestParam String name, @RequestParam String email) {
        financeService.createUser(name, email);
        return "redirect:/";
    }

    @GetMapping("/create-account")
    public String createAccountForm(Model model, java.security.Principal principal) {
        if (principal == null) {
            return "redirect:/login";
        }
        return "create-account";
    }

    @PostMapping("/create-account")
    public String createAccount(@RequestParam String accountName,
            @RequestParam double initialBalance,
            java.security.Principal principal,
            Model model) {
        if (principal == null) {
            return "redirect:/login";
        }

        try {
            // Get the currently authenticated user
            String username = principal.getName();
            User user = userService.findByUsername(username);

            if (user == null) {
                model.addAttribute("error", "User not found. Please log in again.");
                return "create-account";
            }

            // Create the account
            Account account = financeService.createAccount(accountName, initialBalance, user.getId());

            if (account == null) {
                model.addAttribute("error", "Failed to create account. Please try again.");
                return "create-account";
            }

            model.addAttribute("success", "Account created successfully!");
            return "redirect:/dashboard";

        } catch (Exception e) {
            model.addAttribute("error", "An error occurred: " + e.getMessage());
            return "create-account";
        }
    }

    @GetMapping("/add-transaction")
    public String addTransactionForm(Model model, java.security.Principal principal) {
        if (principal == null) {
            return "redirect:/login";
        }

        // Get the currently authenticated user
        String username = principal.getName();
        User user = userService.findByUsername(username);

        if (user != null) {
            // Get accounts and wallets for the current user only
            List<Account> accounts = financeService.getAccountsByUser(user.getId());
            List<Wallet> wallets = walletService.getWalletsByUser(user.getId());
            model.addAttribute("accounts", accounts);
            model.addAttribute("wallets", wallets);
            model.addAttribute("currentUser", user);
        }

        return "add-transaction";
    }

    @PostMapping("/add-transaction")
    public String addTransaction(@RequestParam Long accountId,
            @RequestParam Long walletId,
            @RequestParam double amount,
            @RequestParam String type,
            @RequestParam String note,
            java.security.Principal principal,
            Model model) {
        if (principal == null) {
            return "redirect:/login";
        }

        try {
            financeService.addTransaction(accountId, walletId, amount, type, note);
            model.addAttribute("success", "Transaction added successfully!");
            return "redirect:/dashboard";
        } catch (Exception e) {
            model.addAttribute("error", "Failed to add transaction: " + e.getMessage());
            return addTransactionForm(model, principal);
        }
    }

    @GetMapping("/accounts/{userId}")
    public String viewAccounts(@PathVariable Long userId, Model model) {
        List<Account> accounts = financeService.getAccountsByUser(userId);
        model.addAttribute("accounts", accounts);
        return "accounts";
    }

    @GetMapping("/transactions/{accountId}")
    public String viewTransactions(@PathVariable Long accountId, Model model) {
        List<Transaction> transactions = financeService.getTransactionsByAccount(accountId);
        model.addAttribute("transactions", transactions);
        return "transactions";
    }

    @GetMapping("/api/accounts/{userId}")
    @ResponseBody
    public List<Account> getAccountsForUser(@PathVariable Long userId) {
        return financeService.getAccountsByUser(userId);
    }
}