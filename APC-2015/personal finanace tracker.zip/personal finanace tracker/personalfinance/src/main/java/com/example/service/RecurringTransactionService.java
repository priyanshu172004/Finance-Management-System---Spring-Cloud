package com.example.service;

import com.example.model.RecurringTransaction;
import com.example.model.Transaction;
import com.example.model.User;
import com.example.repository.RecurringTransactionRepository;
import com.example.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.scheduling.annotation.Scheduled;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class RecurringTransactionService {

    @Autowired
    private RecurringTransactionRepository recurringTransactionRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private FinanceService financeService;

    @Transactional(readOnly = true)
    public List<RecurringTransaction> getUserRecurringTransactions(User user) {
        return recurringTransactionRepository.findByUserAndActiveTrue(user);
    }

    @Transactional(readOnly = true)
    public List<RecurringTransaction> getDueTransactions(User user) {
        return recurringTransactionRepository.findDueTransactions(user, LocalDateTime.now());
    }

    @Transactional
    public RecurringTransaction createRecurringTransaction(RecurringTransaction recurringTransaction) {
        return recurringTransactionRepository.save(recurringTransaction);
    }

    @Transactional
    public RecurringTransaction updateRecurringTransaction(RecurringTransaction recurringTransaction) {
        return recurringTransactionRepository.save(recurringTransaction);
    }

    @Transactional
    public void deleteRecurringTransaction(Long id) {
        Optional<RecurringTransaction> recurringTransaction = recurringTransactionRepository.findById(id);
        if (recurringTransaction.isPresent()) {
            RecurringTransaction rt = recurringTransaction.get();
            rt.setActive(false);
            recurringTransactionRepository.save(rt);
        }
    }

    @Transactional(readOnly = true)
    public Optional<RecurringTransaction> getRecurringTransactionById(Long id) {
        return recurringTransactionRepository.findById(id);
    }

    @Transactional
    public Transaction processRecurringTransaction(Long recurringTransactionId) {
        Optional<RecurringTransaction> optionalRt = recurringTransactionRepository.findById(recurringTransactionId);

        if (optionalRt.isPresent()) {
            RecurringTransaction rt = optionalRt.get();

            // Create the actual transaction
            Transaction transaction = new Transaction();
            transaction.setAmount(rt.getAmount());
            transaction.setType(rt.getType().name());
            transaction.setNote("Auto-generated from: " + rt.getName());
            transaction.setAccount(rt.getAccount());
            transaction.setWallet(rt.getWallet());
            transaction.setCategory(rt.getCategory());
            transaction.setRecurringTransaction(rt);

            // Save the transaction
            transaction = transactionRepository.save(transaction);

            // Update the next due date
            rt.setNextDueDate(rt.calculateNextDueDate());
            recurringTransactionRepository.save(rt);

            return transaction;
        }

        throw new RuntimeException("Recurring transaction not found with id: " + recurringTransactionId);
    }

    // Scheduled task to process all due recurring transactions
    @Scheduled(cron = "0 0 6 * * ?") // Run daily at 6 AM
    @Transactional
    public void processAllDueRecurringTransactions() {
        List<RecurringTransaction> dueTransactions = recurringTransactionRepository
                .findAllDueAutoProcessTransactions(LocalDateTime.now());

        for (RecurringTransaction rt : dueTransactions) {
            try {
                processRecurringTransaction(rt.getId());
            } catch (Exception e) {
                // Log error but continue processing other transactions
                System.err.println("Error processing recurring transaction " + rt.getId() + ": " + e.getMessage());
            }
        }
    }

    @Transactional(readOnly = true)
    public RecurringSummary getRecurringSummary(User user) {
        Long totalActive = recurringTransactionRepository.countActiveRecurringTransactions(user);
        Double monthlyIncome = recurringTransactionRepository.getTotalAmountByType(
                user, RecurringTransaction.TransactionType.INCOME);
        Double monthlyExpenses = recurringTransactionRepository.getTotalAmountByType(
                user, RecurringTransaction.TransactionType.EXPENSE);

        if (totalActive == null)
            totalActive = 0L;
        if (monthlyIncome == null)
            monthlyIncome = 0.0;
        if (monthlyExpenses == null)
            monthlyExpenses = 0.0;

        return new RecurringSummary(totalActive, monthlyIncome, monthlyExpenses, monthlyIncome - monthlyExpenses);
    }

    public static class RecurringSummary {
        private final Long totalActive;
        private final Double monthlyIncome;
        private final Double monthlyExpenses;
        private final Double netMonthly;

        public RecurringSummary(Long totalActive, Double monthlyIncome, Double monthlyExpenses, Double netMonthly) {
            this.totalActive = totalActive;
            this.monthlyIncome = monthlyIncome;
            this.monthlyExpenses = monthlyExpenses;
            this.netMonthly = netMonthly;
        }

        public Long getTotalActive() {
            return totalActive;
        }

        public Double getMonthlyIncome() {
            return monthlyIncome;
        }

        public Double getMonthlyExpenses() {
            return monthlyExpenses;
        }

        public Double getNetMonthly() {
            return netMonthly;
        }
    }
}