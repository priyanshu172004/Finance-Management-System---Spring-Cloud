package com.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.model.Wallet;
import java.util.List;

public interface WalletRepository extends JpaRepository<Wallet, Long> {
    List<Wallet> findByUserId(Long userId);

    Wallet findByIdAndUserId(Long id, Long userId);
}