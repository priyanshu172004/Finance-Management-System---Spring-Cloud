package com.example.service;

import com.example.model.TransactionCategory;
import com.example.model.Wallet;
import com.example.model.User;
import com.example.repository.TransactionCategoryRepository;
import com.example.repository.WalletRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class DataInitializationService implements CommandLineRunner {

    @Autowired
    private TransactionCategoryRepository categoryRepository;

    @Override
    @Transactional
    public void run(String... args) throws Exception {
        initializeDefaultCategories();
    }

    private void initializeDefaultCategories() {
        if (categoryRepository.count() == 0) {
            // Income categories
            categoryRepository.save(new TransactionCategory("Salary", "INCOME", "#27ae60", "💰"));
            categoryRepository.save(new TransactionCategory("Freelance", "INCOME", "#2ecc71", "💻"));
            categoryRepository.save(new TransactionCategory("Business", "INCOME", "#16a085", "🏢"));
            categoryRepository.save(new TransactionCategory("Investment Returns", "INCOME", "#1abc9c", "📈"));
            categoryRepository.save(new TransactionCategory("Other Income", "INCOME", "#48c9b0", "💵"));

            // Expense categories
            categoryRepository.save(new TransactionCategory("Food & Dining", "EXPENSE", "#e74c3c", "🍽️"));
            categoryRepository.save(new TransactionCategory("Transportation", "EXPENSE", "#f39c12", "🚗"));
            categoryRepository.save(new TransactionCategory("Shopping", "EXPENSE", "#9b59b6", "🛍️"));
            categoryRepository.save(new TransactionCategory("Entertainment", "EXPENSE", "#e67e22", "🎬"));
            categoryRepository.save(new TransactionCategory("Bills & Utilities", "EXPENSE", "#34495e", "💡"));
            categoryRepository.save(new TransactionCategory("Healthcare", "EXPENSE", "#c0392b", "🏥"));
            categoryRepository.save(new TransactionCategory("Education", "EXPENSE", "#3498db", "📚"));
            categoryRepository.save(new TransactionCategory("Travel", "EXPENSE", "#8e44ad", "✈️"));
            categoryRepository.save(new TransactionCategory("Other Expenses", "EXPENSE", "#95a5a6", "💸"));
        }
    }

    public void createDefaultWalletsForUser(User user, WalletRepository walletRepository) {
        // Create default wallets for new user
        walletRepository.save(new Wallet("Main Income", "INCOME", "USD", "Primary income source", "#27ae60", user));
        walletRepository
                .save(new Wallet("Freelance Income", "FREELANCE", "USD", "Freelance and side income", "#2ecc71", user));
        walletRepository
                .save(new Wallet("Daily Spending", "SPENDING", "USD", "Daily expenses and purchases", "#e74c3c", user));
        walletRepository.save(new Wallet("Savings", "SAVINGS", "USD", "Emergency fund and savings", "#3498db", user));
    }
}