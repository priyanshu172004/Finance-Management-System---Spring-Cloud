package com.example.controller;

import com.example.model.Budget;
import com.example.model.User;
import com.example.service.BudgetService;
import com.example.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.validation.Valid;
import java.security.Principal;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/budgets")
public class BudgetController {

    @Autowired
    private BudgetService budgetService;

    @Autowired
    private UserService userService;

    @GetMapping
    public String budgets(Model model, Authentication authentication) {
        User user = userService.findByUsername(authentication.getName());
        List<Budget> budgets = budgetService.getUserBudgets(user);
        List<Budget> overBudgets = budgetService.getOverBudgets(user);
        BudgetService.BudgetSummary summary = budgetService.getBudgetSummary(user);

        model.addAttribute("budgets", budgets);
        model.addAttribute("overBudgets", overBudgets);
        model.addAttribute("budgetSummary", summary);
        model.addAttribute("activeBudgets", budgetService.getActiveBudgets(user));

        return "budgets/list";
    }

    @GetMapping("/create")
    public String createBudgetForm(Model model) {
        model.addAttribute("budget", new Budget());
        return "budgets/create";
    }

    @PostMapping("/create")
    public String createBudget(@Valid @ModelAttribute("budget") Budget budget,
            BindingResult result,
            Authentication authentication,
            RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            return "budgets/create";
        }

        User user = userService.findByUsername(authentication.getName());
        budget.setUser(user);

        try {
            budgetService.createBudget(budget);
            redirectAttributes.addFlashAttribute("successMessage", "Budget created successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error creating budget: " + e.getMessage());
        }

        return "redirect:/budgets";
    }

    @GetMapping("/edit/{id}")
    public String editBudgetForm(@PathVariable Long id, Model model, Authentication authentication) {
        User user = userService.findByUsername(authentication.getName());
        Optional<Budget> budget = budgetService.getBudgetById(id);

        if (budget.isPresent() && budget.get().getUser().getId().equals(user.getId())) {
            model.addAttribute("budget", budget.get());
            return "budgets/edit";
        }

        return "redirect:/budgets";
    }

    @PostMapping("/edit/{id}")
    public String editBudget(@PathVariable Long id,
            @Valid @ModelAttribute("budget") Budget budget,
            BindingResult result,
            Authentication authentication,
            RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            return "budgets/edit";
        }

        User user = userService.findByUsername(authentication.getName());
        Optional<Budget> existingBudget = budgetService.getBudgetById(id);

        if (existingBudget.isPresent() && existingBudget.get().getUser().getId().equals(user.getId())) {
            budget.setId(id);
            budget.setUser(user);

            try {
                budgetService.updateBudget(budget);
                // Recalculate spending for this budget
                budgetService.recalculateBudgetSpending(budget);
                redirectAttributes.addFlashAttribute("successMessage", "Budget updated successfully!");
            } catch (Exception e) {
                redirectAttributes.addFlashAttribute("errorMessage", "Error updating budget: " + e.getMessage());
            }
        }

        return "redirect:/budgets";
    }

    @PostMapping("/delete/{id}")
    public String deleteBudget(@PathVariable Long id,
            Authentication authentication,
            RedirectAttributes redirectAttributes) {
        User user = userService.findByUsername(authentication.getName());
        Optional<Budget> budget = budgetService.getBudgetById(id);

        if (budget.isPresent() && budget.get().getUser().getId().equals(user.getId())) {
            try {
                budgetService.deleteBudget(id);
                redirectAttributes.addFlashAttribute("successMessage", "Budget deleted successfully!");
            } catch (Exception e) {
                redirectAttributes.addFlashAttribute("errorMessage", "Error deleting budget: " + e.getMessage());
            }
        }

        return "redirect:/budgets";
    }

    @GetMapping("/view/{id}")
    public String viewBudget(@PathVariable Long id, Model model, Authentication authentication) {
        User user = userService.findByUsername(authentication.getName());
        Optional<Budget> budget = budgetService.getBudgetById(id);

        if (budget.isPresent() && budget.get().getUser().getId().equals(user.getId())) {
            model.addAttribute("budget", budget.get());
            return "budgets/view";
        }

        return "redirect:/budgets";
    }

    @PostMapping("/recalculate/{id}")
    public String recalculateBudget(@PathVariable Long id,
            Authentication authentication,
            RedirectAttributes redirectAttributes) {
        User user = userService.findByUsername(authentication.getName());
        Optional<Budget> budget = budgetService.getBudgetById(id);

        if (budget.isPresent() && budget.get().getUser().getId().equals(user.getId())) {
            try {
                budgetService.recalculateBudgetSpending(budget.get());
                redirectAttributes.addFlashAttribute("successMessage", "Budget spending recalculated successfully!");
            } catch (Exception e) {
                redirectAttributes.addFlashAttribute("errorMessage", "Error recalculating budget: " + e.getMessage());
            }
        }

        return "redirect:/budgets";
    }
}