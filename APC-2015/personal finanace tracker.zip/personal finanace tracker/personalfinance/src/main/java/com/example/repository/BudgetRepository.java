package com.example.repository;

import com.example.model.Budget;
import com.example.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface BudgetRepository extends JpaRepository<Budget, Long> {

    List<Budget> findByUserAndActiveTrue(User user);

    List<Budget> findByUserAndActiveTrueOrderByCreatedAtDesc(User user);

    @Query("SELECT b FROM Budget b WHERE b.user = :user AND b.active = true AND :currentDate BETWEEN b.startDate AND b.endDate")
    List<Budget> findActivebudgetsForUser(@Param("user") User user, @Param("currentDate") LocalDate currentDate);

    @Query("SELECT b FROM Budget b WHERE b.user = :user AND b.spentAmount > b.budgetAmount AND b.active = true")
    List<Budget> findOverBudgetsForUser(@Param("user") User user);

    @Query("SELECT b FROM Budget b WHERE b.user = :user AND b.category.id = :categoryId AND b.active = true AND :currentDate BETWEEN b.startDate AND b.endDate")
    List<Budget> findBudgetByCategoryAndUser(@Param("user") User user, @Param("categoryId") Long categoryId,
            @Param("currentDate") LocalDate currentDate);

    @Query("SELECT SUM(b.budgetAmount) FROM Budget b WHERE b.user = :user AND b.active = true AND :currentDate BETWEEN b.startDate AND b.endDate")
    Double getTotalBudgetAmountForUser(@Param("user") User user, @Param("currentDate") LocalDate currentDate);

    @Query("SELECT SUM(b.spentAmount) FROM Budget b WHERE b.user = :user AND b.active = true AND :currentDate BETWEEN b.startDate AND b.endDate")
    Double getTotalSpentAmountForUser(@Param("user") User user, @Param("currentDate") LocalDate currentDate);
}