package com.example.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private double amount;
    private String type; // INCOME or EXPENSE
    private String note;
    private LocalDateTime transactionDate;

    @ManyToOne
    private Account account;

    @ManyToOne
    private Wallet wallet;

    @ManyToOne
    private TransactionCategory category;

    @ManyToOne
    private RecurringTransaction recurringTransaction;

    private String tags; // Comma-separated tags
    private String attachmentPath; // File path for receipts/documents
    private boolean reconciled = false; // For bank reconciliation
    private String reference; // External reference number

    // Constructors
    public Transaction() {
        this.transactionDate = LocalDateTime.now();
    }

    public Transaction(double amount, String type, String note, Account account) {
        this.amount = amount;
        this.type = type;
        this.note = note;
        this.account = account;
        this.transactionDate = LocalDateTime.now();
    }

    public Transaction(double amount, String type, String note, Account account, Wallet wallet) {
        this.amount = amount;
        this.type = type;
        this.note = note;
        this.account = account;
        this.wallet = wallet;
        this.transactionDate = LocalDateTime.now();
    }

    public Transaction(double amount, String type, String note, Account account, Wallet wallet,
            TransactionCategory category) {
        this.amount = amount;
        this.type = type;
        this.note = note;
        this.account = account;
        this.wallet = wallet;
        this.category = category;
        this.transactionDate = LocalDateTime.now();
    }

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public Wallet getWallet() {
        return wallet;
    }

    public void setWallet(Wallet wallet) {
        this.wallet = wallet;
    }

    public TransactionCategory getCategory() {
        return category;
    }

    public void setCategory(TransactionCategory category) {
        this.category = category;
    }

    public LocalDateTime getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(LocalDateTime transactionDate) {
        this.transactionDate = transactionDate;
    }

    public RecurringTransaction getRecurringTransaction() {
        return recurringTransaction;
    }

    public void setRecurringTransaction(RecurringTransaction recurringTransaction) {
        this.recurringTransaction = recurringTransaction;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    public String getAttachmentPath() {
        return attachmentPath;
    }

    public void setAttachmentPath(String attachmentPath) {
        this.attachmentPath = attachmentPath;
    }

    public boolean isReconciled() {
        return reconciled;
    }

    public void setReconciled(boolean reconciled) {
        this.reconciled = reconciled;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }
}