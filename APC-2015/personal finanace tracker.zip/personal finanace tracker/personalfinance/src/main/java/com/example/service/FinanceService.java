package com.example.service;

import com.example.model.Account;
import com.example.model.Transaction;
import com.example.model.User;
import com.example.model.Wallet;
import com.example.repository.AccountRepository;
import com.example.repository.TransactionRepository;
import com.example.repository.UserRepository;
import com.example.repository.WalletRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class FinanceService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private WalletRepository walletRepository;

    @Transactional
    public User createUser(String name, String email, String username, String password) {
        User user = new User(name, email, username, password);
        return userRepository.save(user);
    }

    // Keep old method for backward compatibility
    @Transactional
    public User createUser(String name, String email) {
        User user = new User(name, email, email, "password"); // Simple default
        return userRepository.save(user);
    }

    @Transactional
    public Account createAccount(String accountName, double initialBalance, Long userId, Long walletId) {
        Optional<User> user = userRepository.findById(userId);
        Optional<Wallet> wallet = walletRepository.findById(walletId);

        if (user.isPresent() && wallet.isPresent()) {
            Account account = new Account(accountName, initialBalance, user.get(), wallet.get());
            return accountRepository.save(account);
        }
        return null;
    }

    // Keep old method for backward compatibility
    @Transactional
    public Account createAccount(String accountName, double initialBalance, Long userId) {
        Optional<User> user = userRepository.findById(userId);
        if (user.isPresent()) {
            // Try to get default wallet or create one
            List<Wallet> wallets = walletRepository.findByUserId(userId);
            Wallet wallet;

            if (wallets.isEmpty()) {
                wallet = new Wallet("Main Wallet", "CASH", "USD", user.get());
                wallet = walletRepository.save(wallet);
            } else {
                wallet = wallets.get(0);
            }

            Account account = new Account(accountName, initialBalance, user.get(), wallet);
            return accountRepository.save(account);
        }
        return null;
    }

    @Transactional
    public Transaction addTransaction(Long accountId, double amount, String type, String note) {
        Optional<Account> accountOpt = accountRepository.findById(accountId);
        if (accountOpt.isPresent()) {
            Account account = accountOpt.get();

            // Update balance
            if ("CREDIT".equalsIgnoreCase(type)) {
                account.setBalance(account.getBalance() + amount);
            } else if ("DEBIT".equalsIgnoreCase(type)) {
                account.setBalance(account.getBalance() - amount);
            }

            accountRepository.save(account);

            Transaction transaction = new Transaction(amount, type.toUpperCase(), note, account);
            return transactionRepository.save(transaction);
        }
        return null;
    }

    @Transactional
    public Transaction addTransaction(Long accountId, Long walletId, double amount, String type, String note) {
        Optional<Account> accountOpt = accountRepository.findById(accountId);
        Optional<Wallet> walletOpt = walletRepository.findById(walletId);

        if (accountOpt.isPresent() && walletOpt.isPresent()) {
            Account account = accountOpt.get();
            Wallet wallet = walletOpt.get();

            // Update balance
            if ("CREDIT".equalsIgnoreCase(type)) {
                account.setBalance(account.getBalance() + amount);
            } else if ("DEBIT".equalsIgnoreCase(type)) {
                account.setBalance(account.getBalance() - amount);
            }

            accountRepository.save(account);

            Transaction transaction = new Transaction(amount, type.toUpperCase(), note, account, wallet);
            return transactionRepository.save(transaction);
        }
        return null;
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public List<Account> getAccountsByUser(Long userId) {
        return accountRepository.findByUserId(userId);
    }

    public List<Account> getAccountsByWallet(Long walletId) {
        return accountRepository.findByWalletId(walletId);
    }

    public List<Transaction> getTransactionsByAccount(Long accountId) {
        return transactionRepository.findByAccountId(accountId);
    }

    public Optional<Account> getAccount(Long accountId) {
        return accountRepository.findById(accountId);
    }

    public double getAccountBalance(Long accountId) {
        Optional<Account> account = accountRepository.findById(accountId);
        return account.map(Account::getBalance).orElse(0.0);
    }

    public List<Transaction> getRecentTransactionsByUser(Long userId, int limit) {
        return transactionRepository.findTop10ByAccountUserIdOrderByTransactionDateDesc(userId);
    }
}