package com.example.controller;

import com.example.model.User;
import com.example.service.AnalyticsService;
import com.example.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.YearMonth;
import java.util.Map;

@Controller
@RequestMapping("/analytics")
public class AnalyticsController {

    @Autowired
    private AnalyticsService analyticsService;

    @Autowired
    private UserService userService;

    @GetMapping
    public String analyticsPage(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User user = userService.findByUsername(auth.getName());

        if (user != null) {
            YearMonth currentMonth = YearMonth.now();
            Map<String, Object> monthlyReport = analyticsService.getMonthlyReport(
                    user, currentMonth.getYear(), currentMonth.getMonthValue());

            Map<String, Object> yearlyReport = analyticsService.getYearlyReport(
                    user, currentMonth.getYear());

            model.addAttribute("user", user);
            model.addAttribute("monthlyReport", monthlyReport);
            model.addAttribute("yearlyReport", yearlyReport);
            model.addAttribute("currentYear", currentMonth.getYear());
            model.addAttribute("currentMonth", currentMonth.getMonthValue());
            model.addAttribute("recentTransactions", analyticsService.getRecentTransactions(user, 10));

            return "analytics";
        }

        return "redirect:/login";
    }

    @GetMapping("/monthly/{year}/{month}")
    public String monthlyReport(@PathVariable int year, @PathVariable int month, Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User user = userService.findByUsername(auth.getName());

        if (user != null) {
            Map<String, Object> monthlyReport = analyticsService.getMonthlyReport(user, year, month);

            model.addAttribute("user", user);
            model.addAttribute("monthlyReport", monthlyReport);
            model.addAttribute("year", year);
            model.addAttribute("month", month);

            return "monthly-report";
        }

        return "redirect:/login";
    }

    @GetMapping("/api/monthly-data/{year}/{month}")
    @ResponseBody
    public Map<String, Object> getMonthlyData(@PathVariable int year, @PathVariable int month) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User user = userService.findByUsername(auth.getName());

        if (user != null) {
            return analyticsService.getMonthlyReport(user, year, month);
        }

        return null;
    }
}