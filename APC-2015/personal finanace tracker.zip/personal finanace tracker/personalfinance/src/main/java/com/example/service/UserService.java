package com.example.service;

import com.example.model.User;
import com.example.model.Wallet;
import com.example.repository.UserRepository;
import com.example.repository.WalletRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private WalletRepository walletRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // @Autowired
    // private DataInitializationService dataInitializationService;

    // Helper methods
    private void createDefaultWalletsForUser(User user) {
        // Create Income wallet
        Wallet incomeWallet = new Wallet();
        incomeWallet.setName("My Income");
        incomeWallet.setWalletType("INCOME");
        incomeWallet.setPurpose("Primary Income");
        incomeWallet.setColor("#4CAF50");
        incomeWallet.setCurrency("USD");
        incomeWallet.setUser(user);
        walletRepository.save(incomeWallet);

        // Create Freelance wallet
        Wallet freelanceWallet = new Wallet();
        freelanceWallet.setName("Freelance");
        freelanceWallet.setWalletType("FREELANCE");
        freelanceWallet.setPurpose("Freelance Income");
        freelanceWallet.setColor("#FF9800");
        freelanceWallet.setCurrency("USD");
        freelanceWallet.setUser(user);
        walletRepository.save(freelanceWallet);

        // Create Spending wallet
        Wallet spendingWallet = new Wallet();
        spendingWallet.setName("Daily Spending");
        spendingWallet.setWalletType("SPENDING");
        spendingWallet.setPurpose("Daily Expenses");
        spendingWallet.setColor("#F44336");
        spendingWallet.setCurrency("USD");
        spendingWallet.setUser(user);
        walletRepository.save(spendingWallet);

        // Create Savings wallet
        Wallet savingsWallet = new Wallet();
        savingsWallet.setName("Savings");
        savingsWallet.setWalletType("SAVINGS");
        savingsWallet.setPurpose("Emergency Fund");
        savingsWallet.setColor("#2196F3");
        savingsWallet.setCurrency("USD");
        savingsWallet.setUser(user);
        walletRepository.save(savingsWallet);
    }

    public boolean usernameExists(String username) {
        return userRepository.existsByUsername(username);
    }

    public boolean emailExists(String email) {
        return userRepository.existsByEmail(email);
    }

    @Transactional
    public User registerUser(String name, String email, String username, String password) {
        // Create and save user
        User user = new User(name, email, username, passwordEncoder.encode(password));
        user = userRepository.save(user);

        // Create default wallets for the user
        createDefaultWalletsForUser(user);

        return user;
    }

    public User findByUsername(String username) {
        return userRepository.findByUsername(username);
    }
}