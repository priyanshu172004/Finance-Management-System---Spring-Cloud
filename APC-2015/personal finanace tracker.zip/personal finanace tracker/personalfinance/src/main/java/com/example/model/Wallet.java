package com.example.model;

import jakarta.persistence.*;

@Entity
public class Wallet {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String walletType; // e.g., "INCOME", "FREELANCE", "SPENDING", "SAVINGS", "INVESTMENT"
    private String currency;
    private String purpose; // Description of wallet purpose
    private String color; // For UI representation

    @ManyToOne
    private User user;

    // Constructors
    public Wallet() {
    }

    public Wallet(String name, String walletType, String currency, User user) {
        this.name = name;
        this.walletType = walletType;
        this.currency = currency;
        this.user = user;
    }

    public Wallet(String name, String walletType, String currency, String purpose, String color, User user) {
        this.name = name;
        this.walletType = walletType;
        this.currency = currency;
        this.purpose = purpose;
        this.color = color;
        this.user = user;
    }

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getWalletType() {
        return walletType;
    }

    public void setWalletType(String walletType) {
        this.walletType = walletType;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
}