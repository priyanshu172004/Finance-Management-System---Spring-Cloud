package com.example.controller;

import com.example.model.Account;
import com.example.model.User;
import com.example.model.Wallet;
import com.example.service.AnalyticsService;
import com.example.service.FinanceService;
import com.example.service.UserService;
import com.example.service.WalletService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/dashboard")
public class DashboardController {

    @Autowired
    private UserService userService;

    @Autowired
    private WalletService walletService;

    @Autowired
    private FinanceService financeService;

    @Autowired
    private AnalyticsService analyticsService;

    @GetMapping
    public String dashboard(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User user = userService.findByUsername(auth.getName());

        if (user != null) {
            // Get current month and year
            LocalDateTime now = LocalDateTime.now();
            int currentYear = now.getYear();
            int currentMonth = now.getMonthValue();

            // Get data for dashboard
            List<Wallet> wallets = walletService.getWalletsByUser(user.getId());
            List<Account> accounts = financeService.getAccountsByUser(user.getId());
            Map<String, Object> monthlyReport = analyticsService.getMonthlyReport(user, currentYear, currentMonth);

            // Get recent transactions (limit to 10)
            List<com.example.model.Transaction> recentTransactions = analyticsService.getRecentTransactions(user, 10);

            // Get wallet analytics
            Map<String, Object> walletAnalytics = analyticsService.getWalletAnalytics(user);

            double totalBalance = accounts.stream()
                    .mapToDouble(Account::getBalance)
                    .sum();

            // Add all required attributes for the dashboard template
            model.addAttribute("user", user);
            model.addAttribute("wallets", wallets);
            model.addAttribute("accounts", accounts);
            model.addAttribute("totalBalance", totalBalance);
            model.addAttribute("monthlyReport", monthlyReport);
            model.addAttribute("recentTransactions", recentTransactions);
            model.addAttribute("walletAnalytics", walletAnalytics);

            return "dashboard";
        }

        return "redirect:/login";
    }
}