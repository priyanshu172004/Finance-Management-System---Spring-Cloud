package com.example.service;

import com.example.model.Transaction;
import com.example.model.User;
import com.example.repository.TransactionRepository;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ReportService {

        @Autowired
        private TransactionRepository transactionRepository;

        @Autowired
        private AnalyticsService analyticsService;

        public byte[] generateMonthlyReport(User user, int year, int month) throws IOException {
                LocalDateTime startDate = LocalDate.of(year, month, 1).atStartOfDay();
                LocalDateTime endDate = startDate.plusMonths(1).minusSeconds(1);

                List<Transaction> transactions = transactionRepository.findByAccountUserAndTransactionDateBetween(
                                user, startDate, endDate);

                return createExcelReport(transactions, "Monthly Report - " + year + "/" + month);
        }

        public byte[] generateYearlyReport(User user, int year) throws IOException {
                LocalDateTime startDate = LocalDate.of(year, 1, 1).atStartOfDay();
                LocalDateTime endDate = LocalDate.of(year, 12, 31).atTime(23, 59, 59);

                List<Transaction> transactions = transactionRepository.findByAccountUserAndTransactionDateBetween(
                                user, startDate, endDate);

                return createExcelReport(transactions, "Yearly Report - " + year);
        }

        public byte[] generateCustomReport(User user, LocalDateTime startDate, LocalDateTime endDate)
                        throws IOException {
                List<Transaction> transactions = transactionRepository.findByAccountUserAndTransactionDateBetween(
                                user, startDate, endDate);

                return createExcelReport(transactions, "Custom Report");
        }

        private byte[] createExcelReport(List<Transaction> transactions, String reportTitle) throws IOException {
                Workbook workbook = new XSSFWorkbook();

                // Summary Sheet
                Sheet summarySheet = workbook.createSheet("Summary");
                createSummarySheet(summarySheet, transactions, reportTitle);

                // Transactions Sheet
                Sheet transactionsSheet = workbook.createSheet("Transactions");
                createTransactionsSheet(transactionsSheet, transactions);

                // Category Analysis Sheet
                Sheet categorySheet = workbook.createSheet("Category Analysis");
                createCategoryAnalysisSheet(categorySheet, transactions);

                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                workbook.write(outputStream);
                workbook.close();

                return outputStream.toByteArray();
        }

        private void createSummarySheet(Sheet sheet, List<Transaction> transactions, String reportTitle) {
                // Create header row
                Row headerRow = sheet.createRow(0);
                headerRow.createCell(0).setCellValue(reportTitle);

                // Calculate summary statistics
                double totalIncome = transactions.stream()
                                .filter(t -> "INCOME".equals(t.getType()))
                                .mapToDouble(Transaction::getAmount)
                                .sum();

                double totalExpenses = transactions.stream()
                                .filter(t -> "EXPENSE".equals(t.getType()))
                                .mapToDouble(Transaction::getAmount)
                                .sum();

                double netAmount = totalIncome - totalExpenses;

                // Create summary rows
                Row incomeRow = sheet.createRow(2);
                incomeRow.createCell(0).setCellValue("Total Income:");
                incomeRow.createCell(1).setCellValue(totalIncome);

                Row expenseRow = sheet.createRow(3);
                expenseRow.createCell(0).setCellValue("Total Expenses:");
                expenseRow.createCell(1).setCellValue(totalExpenses);

                Row netRow = sheet.createRow(4);
                netRow.createCell(0).setCellValue("Net Amount:");
                netRow.createCell(1).setCellValue(netAmount);

                Row countRow = sheet.createRow(5);
                countRow.createCell(0).setCellValue("Total Transactions:");
                countRow.createCell(1).setCellValue(transactions.size());
        }

        private void createTransactionsSheet(Sheet sheet, List<Transaction> transactions) {
                // Create header row
                Row headerRow = sheet.createRow(0);
                headerRow.createCell(0).setCellValue("Date");
                headerRow.createCell(1).setCellValue("Amount");
                headerRow.createCell(2).setCellValue("Type");
                headerRow.createCell(3).setCellValue("Category");
                headerRow.createCell(4).setCellValue("Account");
                headerRow.createCell(5).setCellValue("Wallet");
                headerRow.createCell(6).setCellValue("Note");

                // Add transaction data
                int rowNum = 1;
                for (Transaction transaction : transactions) {
                        Row row = sheet.createRow(rowNum++);
                        row.createCell(0).setCellValue(transaction.getTransactionDate().toString());
                        row.createCell(1).setCellValue(transaction.getAmount());
                        row.createCell(2).setCellValue(transaction.getType());
                        row.createCell(3).setCellValue(
                                        transaction.getCategory() != null ? transaction.getCategory().getName() : "");
                        row.createCell(4).setCellValue(
                                        transaction.getAccount() != null ? transaction.getAccount().getName() : "");
                        row.createCell(5).setCellValue(
                                        transaction.getWallet() != null ? transaction.getWallet().getName() : "");
                        row.createCell(6).setCellValue(transaction.getNote() != null ? transaction.getNote() : "");
                }

                // Auto-size columns
                for (int i = 0; i < 7; i++) {
                        sheet.autoSizeColumn(i);
                }
        }

        private void createCategoryAnalysisSheet(Sheet sheet, List<Transaction> transactions) {
                // Group transactions by category
                Map<String, Double> categoryTotals = transactions.stream()
                                .filter(t -> t.getCategory() != null)
                                .collect(Collectors.groupingBy(
                                                t -> t.getCategory().getName(),
                                                Collectors.summingDouble(Transaction::getAmount)));

                // Create header row
                Row headerRow = sheet.createRow(0);
                headerRow.createCell(0).setCellValue("Category");
                headerRow.createCell(1).setCellValue("Total Amount");
                headerRow.createCell(2).setCellValue("Transaction Count");

                // Add category data
                int rowNum = 1;
                for (Map.Entry<String, Double> entry : categoryTotals.entrySet()) {
                        Row row = sheet.createRow(rowNum++);
                        row.createCell(0).setCellValue(entry.getKey());
                        row.createCell(1).setCellValue(entry.getValue());

                        long count = transactions.stream()
                                        .filter(t -> t.getCategory() != null
                                                        && t.getCategory().getName().equals(entry.getKey()))
                                        .count();
                        row.createCell(2).setCellValue(count);
                }

                // Auto-size columns
                for (int i = 0; i < 3; i++) {
                        sheet.autoSizeColumn(i);
                }
        }

        public FinancialSummaryReport getFinancialSummary(User user, LocalDateTime startDate, LocalDateTime endDate) {
                List<Transaction> transactions = transactionRepository.findByAccountUserAndTransactionDateBetween(
                                user, startDate, endDate);

                double totalIncome = transactions.stream()
                                .filter(t -> "INCOME".equals(t.getType()))
                                .mapToDouble(Transaction::getAmount)
                                .sum();

                double totalExpenses = transactions.stream()
                                .filter(t -> "EXPENSE".equals(t.getType()))
                                .mapToDouble(Transaction::getAmount)
                                .sum();

                Map<String, Double> categoryBreakdown = transactions.stream()
                                .filter(t -> t.getCategory() != null)
                                .collect(Collectors.groupingBy(
                                                t -> t.getCategory().getName(),
                                                Collectors.summingDouble(Transaction::getAmount)));

                return new FinancialSummaryReport(
                                totalIncome,
                                totalExpenses,
                                totalIncome - totalExpenses,
                                transactions.size(),
                                categoryBreakdown);
        }

        public static class FinancialSummaryReport {
                private final double totalIncome;
                private final double totalExpenses;
                private final double netAmount;
                private final int transactionCount;
                private final Map<String, Double> categoryBreakdown;

                public FinancialSummaryReport(double totalIncome, double totalExpenses, double netAmount,
                                int transactionCount, Map<String, Double> categoryBreakdown) {
                        this.totalIncome = totalIncome;
                        this.totalExpenses = totalExpenses;
                        this.netAmount = netAmount;
                        this.transactionCount = transactionCount;
                        this.categoryBreakdown = categoryBreakdown;
                }

                // Getters
                public double getTotalIncome() {
                        return totalIncome;
                }

                public double getTotalExpenses() {
                        return totalExpenses;
                }

                public double getNetAmount() {
                        return netAmount;
                }

                public int getTransactionCount() {
                        return transactionCount;
                }

                public Map<String, Double> getCategoryBreakdown() {
                        return categoryBreakdown;
                }
        }
}