package com.example.service;

import com.example.model.Transaction;
import com.example.model.User;
import com.example.model.Wallet;
import com.example.repository.TransactionRepository;
import com.example.repository.WalletRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class AnalyticsService {

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private WalletRepository walletRepository;

    public Map<String, Object> getMonthlyReport(User user, int year, int month) {
        YearMonth yearMonth = YearMonth.of(year, month);
        LocalDateTime startDate = yearMonth.atDay(1).atStartOfDay();
        LocalDateTime endDate = yearMonth.atEndOfMonth().atTime(23, 59, 59);

        List<Transaction> transactions = transactionRepository.findByUserIdAndDateRange(
                user.getId(), startDate, endDate);

        Map<String, Object> report = new HashMap<>();

        // Calculate totals
        double totalIncome = transactions.stream()
                .filter(t -> "INCOME".equals(t.getType()))
                .mapToDouble(Transaction::getAmount)
                .sum();

        double totalExpenses = transactions.stream()
                .filter(t -> "EXPENSE".equals(t.getType()))
                .mapToDouble(Transaction::getAmount)
                .sum();

        double netIncome = totalIncome - totalExpenses;

        report.put("totalIncome", totalIncome);
        report.put("totalExpenses", totalExpenses);
        report.put("netIncome", netIncome);
        report.put("transactionCount", transactions.size());

        // Group by category
        Map<String, Double> incomeByCategory = transactions.stream()
                .filter(t -> "INCOME".equals(t.getType()))
                .collect(Collectors.groupingBy(
                        t -> t.getCategory() != null ? t.getCategory().getName() : "Uncategorized",
                        Collectors.summingDouble(Transaction::getAmount)));

        Map<String, Double> expensesByCategory = transactions.stream()
                .filter(t -> "EXPENSE".equals(t.getType()))
                .collect(Collectors.groupingBy(
                        t -> t.getCategory() != null ? t.getCategory().getName() : "Uncategorized",
                        Collectors.summingDouble(Transaction::getAmount)));

        report.put("incomeByCategory", incomeByCategory);
        report.put("expensesByCategory", expensesByCategory);

        // Group by wallet
        Map<String, Double> incomeByWallet = transactions.stream()
                .filter(t -> "INCOME".equals(t.getType()))
                .collect(Collectors.groupingBy(
                        t -> t.getWallet() != null ? t.getWallet().getName() : "No Wallet",
                        Collectors.summingDouble(Transaction::getAmount)));

        Map<String, Double> expensesByWallet = transactions.stream()
                .filter(t -> "EXPENSE".equals(t.getType()))
                .collect(Collectors.groupingBy(
                        t -> t.getWallet() != null ? t.getWallet().getName() : "No Wallet",
                        Collectors.summingDouble(Transaction::getAmount)));

        report.put("incomeByWallet", incomeByWallet);
        report.put("expensesByWallet", expensesByWallet);

        // Daily breakdown for chart
        Map<Integer, Double> dailyIncome = new HashMap<>();
        Map<Integer, Double> dailyExpenses = new HashMap<>();

        for (int day = 1; day <= yearMonth.lengthOfMonth(); day++) {
            dailyIncome.put(day, 0.0);
            dailyExpenses.put(day, 0.0);
        }

        transactions.forEach(t -> {
            int day = t.getTransactionDate().getDayOfMonth();
            if ("INCOME".equals(t.getType())) {
                dailyIncome.put(day, dailyIncome.get(day) + t.getAmount());
            } else {
                dailyExpenses.put(day, dailyExpenses.get(day) + t.getAmount());
            }
        });

        report.put("dailyIncome", dailyIncome);
        report.put("dailyExpenses", dailyExpenses);

        return report;
    }

    public Map<String, Object> getYearlyReport(User user, int year) {
        Map<String, Object> yearlyReport = new HashMap<>();
        Map<Integer, Double> monthlyIncome = new HashMap<>();
        Map<Integer, Double> monthlyExpenses = new HashMap<>();

        for (int month = 1; month <= 12; month++) {
            Map<String, Object> monthReport = getMonthlyReport(user, year, month);
            monthlyIncome.put(month, (Double) monthReport.get("totalIncome"));
            monthlyExpenses.put(month, (Double) monthReport.get("totalExpenses"));
        }

        double yearlyTotalIncome = monthlyIncome.values().stream().mapToDouble(Double::doubleValue).sum();
        double yearlyTotalExpenses = monthlyExpenses.values().stream().mapToDouble(Double::doubleValue).sum();

        yearlyReport.put("monthlyIncome", monthlyIncome);
        yearlyReport.put("monthlyExpenses", monthlyExpenses);
        yearlyReport.put("yearlyTotalIncome", yearlyTotalIncome);
        yearlyReport.put("yearlyTotalExpenses", yearlyTotalExpenses);
        yearlyReport.put("yearlyNetIncome", yearlyTotalIncome - yearlyTotalExpenses);

        return yearlyReport;
    }

    public List<Transaction> getRecentTransactions(User user, int limit) {
        List<Transaction> allTransactions = transactionRepository.findByUserId(user.getId());
        return allTransactions.stream()
                .sorted((t1, t2) -> t2.getTransactionDate().compareTo(t1.getTransactionDate()))
                .limit(limit)
                .collect(Collectors.toList());
    }

    public Map<String, Object> getWalletAnalytics(User user) {
        List<Transaction> allTransactions = transactionRepository.findByUserId(user.getId());
        List<Wallet> userWallets = walletRepository.findByUserId(user.getId());
        Map<String, Object> walletAnalytics = new HashMap<>();

        // Group transactions by wallet
        Map<String, List<Transaction>> transactionsByWallet = allTransactions.stream()
                .collect(Collectors.groupingBy(
                        t -> t.getWallet() != null ? t.getWallet().getName() : "No Wallet"));

        Map<String, Double> walletTotals = new HashMap<>();
        Map<String, Integer> walletTransactionCounts = new HashMap<>();
        Map<String, String> walletTypes = new HashMap<>();
        Map<String, String> walletColors = new HashMap<>();

        // Initialize all user wallets with zero values
        userWallets.forEach(wallet -> {
            walletTotals.put(wallet.getName(), 0.0);
            walletTransactionCounts.put(wallet.getName(), 0);
            walletTypes.put(wallet.getName(), wallet.getWalletType());
            walletColors.put(wallet.getName(), wallet.getColor());
        });

        // Update with actual transaction data
        transactionsByWallet.forEach((walletName, transactions) -> {
            double total = transactions.stream()
                    .mapToDouble(t -> {
                        String type = t.getType();
                        // Handle both CREDIT/DEBIT and INCOME/EXPENSE types
                        if ("INCOME".equals(type) || "CREDIT".equals(type)) {
                            return t.getAmount();
                        } else if ("EXPENSE".equals(type) || "DEBIT".equals(type)) {
                            return -t.getAmount();
                        }
                        return 0.0; // Default for unknown types
                    })
                    .sum();
            walletTotals.put(walletName, total);
            walletTransactionCounts.put(walletName, transactions.size());

            // Update wallet type and color from first transaction if not already set
            if (!transactions.isEmpty() && transactions.get(0).getWallet() != null) {
                walletTypes.put(walletName, transactions.get(0).getWallet().getWalletType());
                walletColors.put(walletName, transactions.get(0).getWallet().getColor());
            }
        });

        walletAnalytics.put("walletTotals", walletTotals);
        walletAnalytics.put("walletTransactionCounts", walletTransactionCounts);
        walletAnalytics.put("walletTypes", walletTypes);
        walletAnalytics.put("walletColors", walletColors);

        return walletAnalytics;
    }
}