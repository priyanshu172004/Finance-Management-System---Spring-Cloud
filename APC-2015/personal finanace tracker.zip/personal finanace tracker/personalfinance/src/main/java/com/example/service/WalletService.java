package com.example.service;

import com.example.model.User;
import com.example.model.Wallet;
import com.example.repository.UserRepository;
import com.example.repository.WalletRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class WalletService {

    @Autowired
    private WalletRepository walletRepository;

    @Autowired
    private UserRepository userRepository;

    public List<Wallet> getWalletsByUser(Long userId) {
        return walletRepository.findByUserId(userId);
    }

    public Optional<Wallet> getWalletById(Long walletId) {
        return walletRepository.findById(walletId);
    }

    @Transactional
    public Wallet createWallet(String name, String walletType, String currency, Long userId) {
        Optional<User> userOpt = userRepository.findById(userId);
        if (userOpt.isPresent()) {
            Wallet wallet = new Wallet(name, walletType, currency, userOpt.get());
            return walletRepository.save(wallet);
        }
        return null;
    }

    @Transactional
    public Wallet createWallet(String name, String walletType, String currency, String purpose, String color,
            Long userId) {
        Optional<User> userOpt = userRepository.findById(userId);
        if (userOpt.isPresent()) {
            Wallet wallet = new Wallet(name, walletType, currency, purpose, color, userOpt.get());
            return walletRepository.save(wallet);
        }
        return null;
    }

    @Transactional
    public boolean deleteWallet(Long walletId, Long userId) {
        Wallet wallet = walletRepository.findByIdAndUserId(walletId, userId);
        if (wallet != null) {
            walletRepository.delete(wallet);
            return true;
        }
        return false;
    }
}