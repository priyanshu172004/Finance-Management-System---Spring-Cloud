package com.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.model.TransactionCategory;
import java.util.List;

public interface TransactionCategoryRepository extends JpaRepository<TransactionCategory, Long> {
    List<TransactionCategory> findByType(String type);
}