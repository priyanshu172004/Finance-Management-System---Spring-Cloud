package com.example.repository;

import com.example.model.RecurringTransaction;
import com.example.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface RecurringTransactionRepository extends JpaRepository<RecurringTransaction, Long> {

    List<RecurringTransaction> findByUserAndActiveTrue(User user);

    @Query("SELECT rt FROM RecurringTransaction rt WHERE rt.user = :user AND rt.active = true AND rt.nextDueDate <= :currentDateTime")
    List<RecurringTransaction> findDueTransactions(@Param("user") User user,
            @Param("currentDateTime") LocalDateTime currentDateTime);

    @Query("SELECT rt FROM RecurringTransaction rt WHERE rt.active = true AND rt.nextDueDate <= :currentDateTime AND rt.autoProcess = true")
    List<RecurringTransaction> findAllDueAutoProcessTransactions(
            @Param("currentDateTime") LocalDateTime currentDateTime);

    List<RecurringTransaction> findByUserAndTypeAndActiveTrue(User user, RecurringTransaction.TransactionType type);

    @Query("SELECT rt FROM RecurringTransaction rt WHERE rt.user = :user AND rt.pattern = :pattern AND rt.active = true")
    List<RecurringTransaction> findByUserAndPattern(@Param("user") User user,
            @Param("pattern") RecurringTransaction.RecurrencePattern pattern);

    @Query("SELECT COUNT(rt) FROM RecurringTransaction rt WHERE rt.user = :user AND rt.active = true")
    Long countActiveRecurringTransactions(@Param("user") User user);

    @Query("SELECT SUM(rt.amount) FROM RecurringTransaction rt WHERE rt.user = :user AND rt.type = :type AND rt.active = true")
    Double getTotalAmountByType(@Param("user") User user, @Param("type") RecurringTransaction.TransactionType type);
}