package com.example.controller;

import com.example.model.FinancialGoal;
import com.example.model.User;
import com.example.service.FinancialGoalService;
import com.example.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.validation.Valid;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/goals")
public class FinancialGoalController {

    @Autowired
    private FinancialGoalService goalService;

    @Autowired
    private UserService userService;

    @GetMapping
    public String goals(Model model, Authentication authentication) {
        User user = userService.findByUsername(authentication.getName());
        List<FinancialGoal> goals = goalService.getUserGoals(user);
        List<FinancialGoal> overdueGoals = goalService.getOverdueGoals(user);
        FinancialGoalService.GoalSummary summary = goalService.getGoalSummary(user);

        model.addAttribute("goals", goals);
        model.addAttribute("overdueGoals", overdueGoals);
        model.addAttribute("goalSummary", summary);
        model.addAttribute("activeGoals", goalService.getActiveGoals(user));

        return "goals/list";
    }

    @GetMapping("/create")
    public String createGoalForm(Model model) {
        model.addAttribute("goal", new FinancialGoal());
        model.addAttribute("goalTypes", FinancialGoal.GoalType.values());
        model.addAttribute("priorities", FinancialGoal.Priority.values());
        return "goals/create";
    }

    @PostMapping("/create")
    public String createGoal(@Valid @ModelAttribute("goal") FinancialGoal goal,
            BindingResult result,
            Authentication authentication,
            RedirectAttributes redirectAttributes,
            Model model) {
        if (result.hasErrors()) {
            model.addAttribute("goalTypes", FinancialGoal.GoalType.values());
            model.addAttribute("priorities", FinancialGoal.Priority.values());
            return "goals/create";
        }

        User user = userService.findByUsername(authentication.getName());
        goal.setUser(user);

        try {
            goalService.createGoal(goal);
            redirectAttributes.addFlashAttribute("successMessage", "Financial goal created successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error creating goal: " + e.getMessage());
        }

        return "redirect:/goals";
    }

    @GetMapping("/edit/{id}")
    public String editGoalForm(@PathVariable Long id, Model model, Authentication authentication) {
        User user = userService.findByUsername(authentication.getName());
        Optional<FinancialGoal> goal = goalService.getGoalById(id);

        if (goal.isPresent() && goal.get().getUser().getId().equals(user.getId())) {
            model.addAttribute("goal", goal.get());
            model.addAttribute("goalTypes", FinancialGoal.GoalType.values());
            model.addAttribute("priorities", FinancialGoal.Priority.values());
            return "goals/edit";
        }

        return "redirect:/goals";
    }

    @PostMapping("/edit/{id}")
    public String editGoal(@PathVariable Long id,
            @Valid @ModelAttribute("goal") FinancialGoal goal,
            BindingResult result,
            Authentication authentication,
            RedirectAttributes redirectAttributes,
            Model model) {
        if (result.hasErrors()) {
            model.addAttribute("goalTypes", FinancialGoal.GoalType.values());
            model.addAttribute("priorities", FinancialGoal.Priority.values());
            return "goals/edit";
        }

        User user = userService.findByUsername(authentication.getName());
        Optional<FinancialGoal> existingGoal = goalService.getGoalById(id);

        if (existingGoal.isPresent() && existingGoal.get().getUser().getId().equals(user.getId())) {
            goal.setId(id);
            goal.setUser(user);

            try {
                goalService.updateGoal(goal);
                redirectAttributes.addFlashAttribute("successMessage", "Goal updated successfully!");
            } catch (Exception e) {
                redirectAttributes.addFlashAttribute("errorMessage", "Error updating goal: " + e.getMessage());
            }
        }

        return "redirect:/goals";
    }

    @PostMapping("/delete/{id}")
    public String deleteGoal(@PathVariable Long id,
            Authentication authentication,
            RedirectAttributes redirectAttributes) {
        User user = userService.findByUsername(authentication.getName());
        Optional<FinancialGoal> goal = goalService.getGoalById(id);

        if (goal.isPresent() && goal.get().getUser().getId().equals(user.getId())) {
            try {
                goalService.deleteGoal(id);
                redirectAttributes.addFlashAttribute("successMessage", "Goal deleted successfully!");
            } catch (Exception e) {
                redirectAttributes.addFlashAttribute("errorMessage", "Error deleting goal: " + e.getMessage());
            }
        }

        return "redirect:/goals";
    }

    @PostMapping("/update-progress/{id}")
    public String updateProgress(@PathVariable Long id,
            @RequestParam Double amount,
            Authentication authentication,
            RedirectAttributes redirectAttributes) {
        User user = userService.findByUsername(authentication.getName());
        Optional<FinancialGoal> goal = goalService.getGoalById(id);

        if (goal.isPresent() && goal.get().getUser().getId().equals(user.getId())) {
            try {
                FinancialGoal updatedGoal = goalService.updateGoalProgress(id, amount);
                if (updatedGoal.isCompleted()) {
                    redirectAttributes.addFlashAttribute("successMessage",
                            "Congratulations! You've completed your goal: " + updatedGoal.getName());
                } else {
                    redirectAttributes.addFlashAttribute("successMessage", "Goal progress updated successfully!");
                }
            } catch (Exception e) {
                redirectAttributes.addFlashAttribute("errorMessage", "Error updating progress: " + e.getMessage());
            }
        }

        return "redirect:/goals";
    }

    @GetMapping("/view/{id}")
    public String viewGoal(@PathVariable Long id, Model model, Authentication authentication) {
        User user = userService.findByUsername(authentication.getName());
        Optional<FinancialGoal> goal = goalService.getGoalById(id);

        if (goal.isPresent() && goal.get().getUser().getId().equals(user.getId())) {
            model.addAttribute("goal", goal.get());
            return "goals/view";
        }

        return "redirect:/goals";
    }

    @GetMapping("/by-type/{type}")
    public String goalsByType(@PathVariable String type, Model model, Authentication authentication) {
        User user = userService.findByUsername(authentication.getName());

        try {
            FinancialGoal.GoalType goalType = FinancialGoal.GoalType.valueOf(type.toUpperCase());
            List<FinancialGoal> goals = goalService.getGoalsByType(user, goalType);
            model.addAttribute("goals", goals);
            model.addAttribute("selectedType", goalType);
            return "goals/by-type";
        } catch (IllegalArgumentException e) {
            return "redirect:/goals";
        }
    }
}