package com.example.controller;

import com.example.model.User;
import com.example.service.ReportService;
import com.example.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.time.LocalDateTime;

@Controller
@RequestMapping("/reports")
public class ReportController {

    @Autowired
    private ReportService reportService;

    @Autowired
    private UserService userService;

    @GetMapping
    public String reports(Model model) {
        return "reports/index";
    }

    @GetMapping("/monthly")
    public ResponseEntity<byte[]> generateMonthlyReport(
            @RequestParam int year,
            @RequestParam int month,
            Authentication authentication) {

        try {
            User user = userService.findByUsername(authentication.getName());
            byte[] report = reportService.generateMonthlyReport(user, year, month);

            String filename = String.format("monthly_report_%d_%02d.xlsx", year, month);

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(report);

        } catch (IOException e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    @GetMapping("/yearly")
    public ResponseEntity<byte[]> generateYearlyReport(
            @RequestParam int year,
            Authentication authentication) {

        try {
            User user = userService.findByUsername(authentication.getName());
            byte[] report = reportService.generateYearlyReport(user, year);

            String filename = String.format("yearly_report_%d.xlsx", year);

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(report);

        } catch (IOException e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    @GetMapping("/custom")
    public ResponseEntity<byte[]> generateCustomReport(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate,
            Authentication authentication) {

        try {
            User user = userService.findByUsername(authentication.getName());
            byte[] report = reportService.generateCustomReport(user, startDate, endDate);

            String filename = String.format("custom_report_%s_to_%s.xlsx",
                    startDate.toLocalDate(), endDate.toLocalDate());

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(report);

        } catch (IOException e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    @GetMapping("/summary")
    @ResponseBody
    public ReportService.FinancialSummaryReport getFinancialSummary(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate,
            Authentication authentication) {

        User user = userService.findByUsername(authentication.getName());
        return reportService.getFinancialSummary(user, startDate, endDate);
    }

    @GetMapping("/dashboard-data")
    @ResponseBody
    public DashboardData getDashboardData(Authentication authentication) {
        User user = userService.findByUsername(authentication.getName());

        // Get current month data
        LocalDateTime startOfMonth = LocalDateTime.now().withDayOfMonth(1).withHour(0).withMinute(0).withSecond(0);
        LocalDateTime endOfMonth = startOfMonth.plusMonths(1).minusSeconds(1);

        ReportService.FinancialSummaryReport monthlyReport = reportService.getFinancialSummary(user, startOfMonth,
                endOfMonth);

        // Get current year data
        LocalDateTime startOfYear = LocalDateTime.now().withDayOfYear(1).withHour(0).withMinute(0).withSecond(0);
        LocalDateTime endOfYear = startOfYear.plusYears(1).minusSeconds(1);

        ReportService.FinancialSummaryReport yearlyReport = reportService.getFinancialSummary(user, startOfYear,
                endOfYear);

        return new DashboardData(monthlyReport, yearlyReport);
    }

    public static class DashboardData {
        private final ReportService.FinancialSummaryReport monthlyData;
        private final ReportService.FinancialSummaryReport yearlyData;

        public DashboardData(ReportService.FinancialSummaryReport monthlyData,
                ReportService.FinancialSummaryReport yearlyData) {
            this.monthlyData = monthlyData;
            this.yearlyData = yearlyData;
        }

        public ReportService.FinancialSummaryReport getMonthlyData() {
            return monthlyData;
        }

        public ReportService.FinancialSummaryReport getYearlyData() {
            return yearlyData;
        }
    }
}