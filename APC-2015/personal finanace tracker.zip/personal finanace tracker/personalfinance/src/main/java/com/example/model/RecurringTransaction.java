package com.example.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "recurring_transactions")
public class RecurringTransaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private Double amount;

    @Enumerated(EnumType.STRING)
    private TransactionType type;

    @Column(length = 500)
    private String description;

    @Enumerated(EnumType.STRING)
    private RecurrencePattern pattern;

    @Column(nullable = false)
    private LocalDateTime nextDueDate;

    @Column(nullable = false)
    private LocalDateTime startDate;

    private LocalDateTime endDate; // null for indefinite

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "account_id")
    private Account account;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "wallet_id")
    private Wallet wallet;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id")
    private TransactionCategory category;

    @OneToMany(mappedBy = "recurringTransaction", cascade = CascadeType.ALL)
    private List<Transaction> generatedTransactions = new ArrayList<>();

    @Column(nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(nullable = false)
    private LocalDateTime updatedAt = LocalDateTime.now();

    private boolean active = true;
    private boolean autoProcess = true; // Automatically create transactions

    public enum TransactionType {
        INCOME, EXPENSE
    }

    public enum RecurrencePattern {
        DAILY, WEEKLY, BIWEEKLY, MONTHLY, QUARTERLY, SEMI_ANNUALLY, ANNUALLY
    }

    // Constructors
    public RecurringTransaction() {
    }

    public RecurringTransaction(String name, Double amount, TransactionType type,
            RecurrencePattern pattern, LocalDateTime startDate, User user) {
        this.name = name;
        this.amount = amount;
        this.type = type;
        this.pattern = pattern;
        this.startDate = startDate;
        this.nextDueDate = startDate;
        this.user = user;
    }

    // Utility methods
    public LocalDateTime calculateNextDueDate() {
        LocalDateTime current = this.nextDueDate;
        switch (pattern) {
            case DAILY:
                return current.plusDays(1);
            case WEEKLY:
                return current.plusWeeks(1);
            case BIWEEKLY:
                return current.plusWeeks(2);
            case MONTHLY:
                return current.plusMonths(1);
            case QUARTERLY:
                return current.plusMonths(3);
            case SEMI_ANNUALLY:
                return current.plusMonths(6);
            case ANNUALLY:
                return current.plusYears(1);
            default:
                return current.plusMonths(1);
        }
    }

    public boolean isDue() {
        return LocalDateTime.now().isAfter(nextDueDate) || LocalDateTime.now().isEqual(nextDueDate);
    }

    public boolean isActive() {
        if (!active)
            return false;
        if (endDate != null && LocalDateTime.now().isAfter(endDate))
            return false;
        return true;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public TransactionType getType() {
        return type;
    }

    public void setType(TransactionType type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public RecurrencePattern getPattern() {
        return pattern;
    }

    public void setPattern(RecurrencePattern pattern) {
        this.pattern = pattern;
    }

    public LocalDateTime getNextDueDate() {
        return nextDueDate;
    }

    public void setNextDueDate(LocalDateTime nextDueDate) {
        this.nextDueDate = nextDueDate;
    }

    public LocalDateTime getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDateTime startDate) {
        this.startDate = startDate;
    }

    public LocalDateTime getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDateTime endDate) {
        this.endDate = endDate;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public Wallet getWallet() {
        return wallet;
    }

    public void setWallet(Wallet wallet) {
        this.wallet = wallet;
    }

    public TransactionCategory getCategory() {
        return category;
    }

    public void setCategory(TransactionCategory category) {
        this.category = category;
    }

    public List<Transaction> getGeneratedTransactions() {
        return generatedTransactions;
    }

    public void setGeneratedTransactions(List<Transaction> generatedTransactions) {
        this.generatedTransactions = generatedTransactions;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public boolean getActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean isAutoProcess() {
        return autoProcess;
    }

    public void setAutoProcess(boolean autoProcess) {
        this.autoProcess = autoProcess;
    }

    @PreUpdate
    public void preUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}