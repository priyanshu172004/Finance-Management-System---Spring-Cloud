package com.example.service;

import com.example.model.Budget;
import com.example.model.Transaction;
import com.example.model.User;
import com.example.repository.BudgetRepository;
import com.example.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class BudgetService {

    @Autowired
    private BudgetRepository budgetRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Transactional(readOnly = true)
    public List<Budget> getUserBudgets(User user) {
        return budgetRepository.findByUserAndActiveTrueOrderByCreatedAtDesc(user);
    }

    @Transactional(readOnly = true)
    public List<Budget> getActiveBudgets(User user) {
        return budgetRepository.findActivebudgetsForUser(user, LocalDate.now());
    }

    @Transactional(readOnly = true)
    public List<Budget> getOverBudgets(User user) {
        return budgetRepository.findOverBudgetsForUser(user);
    }

    @Transactional
    public Budget createBudget(Budget budget) {
        return budgetRepository.save(budget);
    }

    @Transactional
    public Budget updateBudget(Budget budget) {
        return budgetRepository.save(budget);
    }

    @Transactional
    public void deleteBudget(Long budgetId) {
        Optional<Budget> budget = budgetRepository.findById(budgetId);
        if (budget.isPresent()) {
            Budget b = budget.get();
            b.setActive(false);
            budgetRepository.save(b);
        }
    }

    @Transactional(readOnly = true)
    public Optional<Budget> getBudgetById(Long id) {
        return budgetRepository.findById(id);
    }

    @Transactional
    public void updateBudgetSpending(User user, Transaction transaction) {
        if ("EXPENSE".equals(transaction.getType()) && transaction.getCategory() != null) {
            List<Budget> budgets = budgetRepository.findBudgetByCategoryAndUser(
                    user, transaction.getCategory().getId(), LocalDate.now());

            for (Budget budget : budgets) {
                budget.setSpentAmount(budget.getSpentAmount() + transaction.getAmount());
                budgetRepository.save(budget);
            }
        }
    }

    @Transactional(readOnly = true)
    public BudgetSummary getBudgetSummary(User user) {
        LocalDate currentDate = LocalDate.now();
        Double totalBudget = budgetRepository.getTotalBudgetAmountForUser(user, currentDate);
        Double totalSpent = budgetRepository.getTotalSpentAmountForUser(user, currentDate);

        if (totalBudget == null)
            totalBudget = 0.0;
        if (totalSpent == null)
            totalSpent = 0.0;

        return new BudgetSummary(totalBudget, totalSpent, totalBudget - totalSpent);
    }

    @Transactional
    public void recalculateBudgetSpending(Budget budget) {
        LocalDate startDate = budget.getStartDate();
        LocalDate endDate = budget.getEndDate();

        Double totalSpent = 0.0;

        if (budget.getCategory() != null) {
            List<Transaction> transactions = transactionRepository.findByCategoryAndTransactionDateBetween(
                    budget.getCategory(), startDate.atStartOfDay(), endDate.atTime(23, 59, 59));

            totalSpent = transactions.stream()
                    .filter(t -> "EXPENSE".equals(t.getType()))
                    .mapToDouble(Transaction::getAmount)
                    .sum();
        }

        budget.setSpentAmount(totalSpent);
        budgetRepository.save(budget);
    }

    public static class BudgetSummary {
        private final Double totalBudget;
        private final Double totalSpent;
        private final Double remaining;

        public BudgetSummary(Double totalBudget, Double totalSpent, Double remaining) {
            this.totalBudget = totalBudget;
            this.totalSpent = totalSpent;
            this.remaining = remaining;
        }

        public Double getTotalBudget() {
            return totalBudget;
        }

        public Double getTotalSpent() {
            return totalSpent;
        }

        public Double getRemaining() {
            return remaining;
        }

        public Double getSpentPercentage() {
            return totalBudget > 0 ? (totalSpent / totalBudget) * 100 : 0.0;
        }
    }
}