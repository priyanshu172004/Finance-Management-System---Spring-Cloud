package com.example.controller;

import com.example.model.User;
import com.example.model.Wallet;
import com.example.service.UserService;
import com.example.service.WalletService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/wallets")
public class WalletController {

    @Autowired
    private WalletService walletService;

    @Autowired
    private UserService userService;

    @GetMapping
    public String listWallets(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User user = userService.findByUsername(auth.getName());

        if (user != null) {
            List<Wallet> wallets = walletService.getWalletsByUser(user.getId());
            model.addAttribute("wallets", wallets);
            model.addAttribute("user", user);
            return "wallets";
        }

        return "redirect:/login";
    }

    @GetMapping("/create")
    public String showCreateWalletForm() {
        return "create-wallet";
    }

    @PostMapping("/create")
    public String createWallet(@RequestParam String name,
            @RequestParam String walletType,
            @RequestParam String currency,
            @RequestParam(required = false) String purpose,
            @RequestParam(required = false) String color,
            RedirectAttributes redirectAttributes) {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User user = userService.findByUsername(auth.getName());

        if (user != null) {
            Wallet wallet = walletService.createWallet(name, walletType, currency, purpose, color, user.getId());

            if (wallet != null) {
                redirectAttributes.addFlashAttribute("success", "Wallet created successfully");
            } else {
                redirectAttributes.addFlashAttribute("error", "Failed to create wallet");
            }
        }

        return "redirect:/wallets";
    }

    @PostMapping("/delete/{id}")
    public String deleteWallet(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User user = userService.findByUsername(auth.getName());

        if (user != null) {
            boolean deleted = walletService.deleteWallet(id, user.getId());

            if (deleted) {
                redirectAttributes.addFlashAttribute("success", "Wallet deleted successfully");
            } else {
                redirectAttributes.addFlashAttribute("error", "Failed to delete wallet");
            }
        }

        return "redirect:/wallets";
    }
}